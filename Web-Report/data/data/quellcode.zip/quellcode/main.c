/* main.c created by user */

/* hilite.me converts your code snippets 
* into pretty-printed HTML format, 
* easily embeddable into blog posts, 
* emails and websites. */

/* Just copy the source code to the 
* left pane, select the language and 
* the color scheme, and click 
* "Highlight!". The HTML from the 
* right pane can now be pasted to your 
* blog or email, no external CSS or 
* Javascript files are required. */

int main () {
    return 0;
}