/* function.c created by user */

void do_function () {
    return 0;
}